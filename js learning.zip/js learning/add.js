// function add(a , b) {
//     return a + b;
// }

// const pi = 3.14

// module.exports = {
//     add,
//     pi
// }

function add(a, b) {
    return a + b;
}

module.export = add
// export function sub(a, b) {
//     return a - b;
// }
// export function multi(a, b) {
//     return a * b;
// }