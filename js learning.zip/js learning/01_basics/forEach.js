const myNums = [1, 2, 3, 4, 5, 6, 7, 8]

// const a = myNums.filter(val => {
//     return val > 4
// })
// const newNum = []
// const b = myNums.forEach(val => {
//     if (val > 4) {
//         newNum.push(val)
//     }
// })

// console.log(b);

// console.log(a);