// // Primitive types

// // Number
// let age = 25;
// let pi = 3.14;

// // String
// let name = 'Harsh';
// let surname = "parmar"
// console.log(``);
// let message = "Hello, world!";

// // Boolean
// let isLogged = true;
// let isMember = false;

// // Undefined 
// let x;
// // console.log(x); // Outputs: undefined

// // Null
// let phoneNumber = null;

// // Symbols
// const RED = Symbol();
// const BLUE = Symbol();

// // Non Premetive types

// // Object
// let person = {
//     name: 'Alice',
//     age: 30,
//     isAdmin: false
// };

// // Array
// let colors = ['red', 'green', 'blue'];
// let numbers = [1, 2, 3, 4, 5];

// // Functions
// function add(a, b) {
//     return a + b;
// }

const s = [1,2,3,4,5,6,7,8,9,10]

