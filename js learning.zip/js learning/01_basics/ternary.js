const gender = "f"

console.log(`${gender === "f" ? "she" : "he"} is a college student`)
 
// const result = false ? "harsh" : null ? "this is truthy" : "this is falsey" // just like else if
// console.log(result);