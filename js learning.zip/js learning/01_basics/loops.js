// for (let i = 1; i <= 5; i++) {
//   console.log(`the value of i is ${i}`); // i 2 ,  2 < 5
//   for (let j = 1; j <= 5; j++) {
//     // j  1, 1 <= 5
//     console.log(`the value of i is ${i} and j is ${j}`);
//   }
// }

// for (let index = 0; index < 10; ) {
//   console.log("sadfas");
// }

// let a = 1;
// let j = 1;

// while (true) {
//   console.log(`the value of i is ${a}`);
//   if (a === 5) {
//     while (j < 10) {
//       console.log(`the value of j is ${j}`);
//       j++;
//       if (j===5) {
//         break;
//       }
//     }
//     break;
//   }
//   a++;
// }


// a = 11
// do {
//   console.log(a);
//   a++;
// } while (a < 10);
