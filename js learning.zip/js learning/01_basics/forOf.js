const arr = [1, 2, 3, 4, 5, 6, 7, 8, 9]

// const cars = ["BMW", "Volvo", "Mini"];

// let text = "";
// for (let x of cars) {
//   text += x;
// }
// console.log(text);

// const str = "hello harsh"

// for (const s of str) {
//     if (s === " ") {
//         continue
//     }
//     console.log(s);
// }


// for (const key in arr) {
//     console.log(key);
// }