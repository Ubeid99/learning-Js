// var a = 2;

// switch (a) {
//   case 0:
//     console.log("this is sunday");
//     break;
//   case 1:
//     console.log("this is Monday");
//     break;
//   case 2:
//     console.log("this is Tuesday");
//     break;
//   case 3:
//     console.log("this is Wednesday");
//     break;
//   case 4:
//     console.log("this is Thursday");
//     break;
//   case 5:
//     console.log("this is Friday");
//     break;
//   case 5:
//     console.log("this is Saturday");
//     break;

//   default:
//     console.log("Not a Day");
//     break;
// }

// const age = 18;

// switch (
//   true // switch ( this value ) and case (this value ) if these values are equal then that case will be executed
// ) {
//   case age <= 2:
//     console.log("you are a baby");
//     break;
//   case age > 2 && age <= 10:
//     console.log("you are a child");
//     break;
//   case age > 10 && age <= 14:
//     console.log("you are a kid");
//     break;
//   case age > 14 && age < 18:
//     console.log("you are a teen");
//     break;
//   case age >= 18:
//     console.log("you are an adult");
//     break;
//   default:
//     console.log("please enter a valid age");
//     break;
// }


const grade = 'e';

switch(true) {
    case grade === 'a':
        console.log('you got an A');
        break;
    case grade === 'b':
        console.log('you got a B');
        break;
    case grade === 'c':
        console.log('you got a C');
        break;
    case grade === 'd':
        console.log('you got a D');
        break;
    case grade === 'e':
        console.log('you got an E');
        break;
    default:
        console.log('please enter a valid grade');
        break;
}
