// const arr = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, "harsh", true, {name : "harsh", role: "developer"}, [10, 20], null, undefined];
// console.log(arr);
    // 0           0 < 10     +
// for(let i = 0; i < arr.length; i++) {
//     console.log(arr);
// }

// arr.forEach(function (el) {
//     console.log("element is ",el);
// })

// arr.map(function (el) {
//     console.log("map element is ",el);
// })

// arr.map((el) => console.log("map element is ",el))



// console.log(arr[123]);