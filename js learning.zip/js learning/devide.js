export default function div(a , b ) {
    return a / b;
}