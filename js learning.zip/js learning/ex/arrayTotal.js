function sum(param, p2, ...params) {
    // params.forEach(el => console.log(el))
    console.log(param);
    console.log(p2);
    console.log(params);
    // params.forEach(function (el) {
    //     console.log(el)
    // })
    
}

const c = sum(1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35);