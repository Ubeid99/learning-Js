const array = [1, 2, 3, 4, 5];
const string = array.toString();

console.log(string); // Output: "1,2,3,4,5"


// The toString() method returns a string with array values separated by commas.
// The toString() method does not change the original array.