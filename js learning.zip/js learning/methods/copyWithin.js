const fruits = ["Banana", "Orange", "Apple", "Mango", "Kiwi"];
// console.log(fruits.copyWithin(2, 1));
// console.log(fruits.copyWithin(2, 0, 2)); // [ 'Banana', 'Orange', 'Banana', 'Orange', 'Kiwi' ]

// The copyWithin() method copies array elements to another position in an array.
// The copyWithin() method overwrites the existing values.
// The copyWithin() method does not add items to the array.
// stx array.copyWithin(target, start, end[el num])