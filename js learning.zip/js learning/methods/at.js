const fruits = ["Banana", "Orange", "Apple", "Mango"];
let fruit = fruits.at(4);
console.log(fruit); // Apple

// The at() method returns an indexed element from an array.
// The at() method returns the same as [].