const fruits = ["Banana", "Orange", "Apple", "Mango"];
fruits.push("Kiwi");

console.log(fruits);


// The push() method adds new items to the end of an array.
// The push() method changes the length of the array.
// The push() method returns the new length