console.log(Array.isArray([1, 2, 3])); // Output: true
console.log(Array.isArray({}));        // Output: false
console.log(Array.isArray('hello'));   // Output: false

// The isArray() method returns true if an object is an array, otherwise false.
// stx : Array.isArray(value: value to be checked)
